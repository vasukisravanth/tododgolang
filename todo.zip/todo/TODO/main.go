package main

import (
	"log"
	"net/http"

	//"github.com/arangodb/go-driver"
	driver "github.com/arangodb/go-driver"
	"github.com/vasuisravanth/Contro"

	//"github.com/arangodb/go-driver/http"
	//"github.com/thedevsaddam/renderer"
	"github.com/gorilla/mux"
	"github.com/vasuisravanth/Arangoconf"
)

// var rnd *renderer.Render
var db driver.Database
var err error
var client driver.Client
var col driver.Collection

type Book struct {
	Title string `json:"Btitle"`
	Price int    `json:"Bprice"`
}

// type Todo struct {
// 	Title     string    `json:"Title"`
// 	Completed bool      `json:"Completedat"`
// 	Createdat time.Time `json:"Created"`
// }

//var list []Todo

// rnd=renderer.New()

//	func HomeHandler(w http.ResponseWriter, r *http.Request) {
//		//err:=rnd.Template(w,http.StatusOK,[]string("static/home.tpl"),nil)
//		if err != nil {
//			panic(err)
//		}
//	}

func main() {

	//init()
	Arangoconf.Initdb()
	r := mux.NewRouter()
	//r.HandleFunc("/", HomeHandler).Methods("GET")
	//r.HandleFunc("/all", Contro.TodoHandler()).Methods("GET")
	//r.HandleFunc("/add", Contro.CreateHandler()).Methods("POST")
	Contro.CreateHandler()
	// r.HandleFunc("/{id}", UpdateHandler).Methods("PUT")
	// r.HandleFunc("/{id}", todoHandler).Methods("DELETE")

	log.Fatal(http.ListenAndServe(":4000", r))
}
