package Arangoconf

import (
	"context"
	"fmt"

	driver "github.com/arangodb/go-driver"
	arangoHttp "github.com/arangodb/go-driver/http"
)

type Book struct {
	Title string `json:"Btitle"`
	Price int    `json:"Bprice"`
}

var ctx = context.Background()

var db driver.Database
var err error
var client driver.Client
var col driver.Collection

func Initdb() {
	if db == nil {

		conn, err := arangoHttp.NewConnection(arangoHttp.ConnectionConfig{
			Endpoints: []string{"http://127.0.0.1:8529"},
		})
		if err != nil {
			// Handle error
			panic(err)
		}
		client, err := driver.NewClient(driver.ClientConfig{
			Connection:     conn,
			Authentication: driver.BasicAuthentication("root", ""),
		})
		if err != nil {
			// Handle error
			panic(err)
		}

		db, err = client.Database(nil, "testdb")
		if err != nil {
			panic(err)
		}
		fmt.Println(db)

		// col, err := db.CreateCollection(ctx, "test2", nil)
		// if err != nil {
		// 	fmt.Println(err)
		// 	panic(err)
		// }

		// book := Book{
		// 	Title: "ArangoDB Cookbook",
		// 	Price: 257,
		// }

		// meta, err := col.CreateDocument(nil, book)

		// if err != nil {
		// 	panic(err)
		// }

		//fmt.Printf("Created document in collection '%s' in database '%s'\n", col.Name(), db.Name())
		//fmt.Println(meta)

	}
}

func Createdocument(insertact string) {
	cur, err := db.Query(ctx, insertact, nil)
	if err != nil {
		panic(err)
	}
	fmt.Println(cur)
}
